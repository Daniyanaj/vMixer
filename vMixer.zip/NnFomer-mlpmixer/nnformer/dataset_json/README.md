# Note
- This code is based on the foundation of nnunet. So in the Json file, the 'numTraining' contains both training nums and validation nums, the concrete division of training cases and validation cases is done in the trainer file in the path: ```nnformer/training/network_training/```
- So the 'numTraining' in the Synapse.json not represents that we use all the cases for training.
